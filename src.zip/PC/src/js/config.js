module.exports = {
    scriptNumber: 2,
    TimeToQuit: 20000,
    TimeToExec: 1000,
    SiteToExec: "https://google.com/"
  };

// 1 >> Auto Farm (Cookie Clicker)
// 2 >> Execute Personalized Script

// https://discord.gg/9QDNKyYKFk

